<?php 
 
 // Create connection
$conn = mysqli_connect("localhost", "root", "root", "FinalProject");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{

  $sql1 = "SELECT Courses.Domain, Courses.Course_Name, Courses.Level, Courses.Image, Courses.Price, Courses.Course_Number, COUNT(Course_Register.Course_Number) FROM Courses INNER JOIN Course_Register ON Course_Register.Course_Number = Courses.Course_Number GROUP BY Course_Register.Course_Number LIMIT 3";

  $result = $conn->query($sql1);

  if ($result->num_rows > 0) {

    $Courses = array();
    //loop through the result
    while($row = mysqli_fetch_array($result))
    { 
      $Domain = $row['Domain'];
      $Course_Name = $row['Course_Name'];
      $Level = $row['Level'];
      $Image = $row['Image'];
      $Price = $row['Price'];
      array_push($Courses, array('Domain' => $Domain,'Course_Name' => $Course_Name, 'Level' => $Level, 'Image' => $Image, 'Price' => $Price));
      }
        $jsondata = json_encode($Courses);
        echo $jsondata; 
    }
    else{
      echo "No Data";
    }


 
  $conn->close();
      
  }

  
 

?>
