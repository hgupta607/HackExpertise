

$(document).ready(function(){

	$('#LoggedIn').text(localStorage.getItem("UserLoggedIn"));
	var data= JSON.parse(localStorage.getItem('currentTest'));
	var cnum = data.cn;
	var domain = data.d;
	$('#Duration').text(data.t);

	//run the php file
	$.ajax({type:'POST',
    	url: "taketest.php",
    	data:{cnum:cnum , domain:domain},
    	success: function(ds){

    	$('#NumQues').text(ds);	

        }
	});

	$("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";
        localStorage.clear();

    });

	});