<?php 

$Course_name = $_POST["Course_name"];
$Domain = $_POST["Domain"];

 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{
 
	
	$sql1 = "SELECT * FROM FinalProject.Quiz WHERE Course_Name = '$Course_name' AND Domain = '$Domain'";
	$result = $conn->query($sql1);
	if($result->num_rows > 0) {
		$QuestionList = array();
		//loop through the result
		while($row = mysqli_fetch_array($result))
		{	$Question = array();
			$Options = array();
			$AnsBit = array();
			$QuestionNum = $row['Question_Number'];
			$QuestionText = $row['Question_Text'];
			array_merge($Question, array('i' => $QuestionNum,'Q' => $QuestionText));
			$sql2 = "SELECT * FROM FinalProject.Solution WHERE Course_Name = '$Course_name' AND Question_Number = '$QuestionNum'";
			$result2 = $conn->query($sql2);
			while($row2 = mysqli_fetch_array($result2))
			{
				array_push($Options,$row['Options_value']);
				if($row['Answer'] == "1")
				{
					array_push($AnsBit,"checked");
				}
				else{
					array_push($AnsBit,"");
				}
			}

			array_merge($Question, array('O1' => $Qptions[0],'O2' => $Qptions[1],'O3' => $Qptions[2],'O4' => $Qptions[3]));
			array_merge($Question, array('O1Check' => $AnsBit[0],'O2Check' => $AnsBit[1],'O3Check' => $AnsBit[2],'O4Check' => $AnsBit[3]));

		}
	}

	$jsondata = json_encode($Question);
	echo $jsondata;
}
  	
 	$conn->close();
 }
 
?>