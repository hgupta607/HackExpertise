$(document).ready(function(){

  if (localStorage.getItem("UserLoggedIn") !== null) {
    $('#LoggedIn').show();
    $('#logoutbutton').show();
    $('#mcbutton').show();
    $('#cartimg').show();
   $('#LoggedIn').text(localStorage.getItem("UserLoggedIn"));
  }
  else{
    $('#cartimg').hide();
    $('#mcbutton').hide();
    $('#LoggedIn').hide();
    $('#logoutbutton').hide();

  }
   	
      $.ajax({url: "ac.php",success: function(ds){
      var obj = jQuery.parseJSON( ds );

      localStorage.setItem('ac', ds);

      for(var i=0 ; i < obj.length;i++)
      {
       
	   $('#wpl').last().append('<div class="col-sm-4 col-lg-4 col-md-4"><div class="thumbnail"><img src="' + obj[i].i + '" alt=""><div class="caption"><h4 class="pull-right">$'+obj[i].p+'</h4><h4><a onclick="desc(this)" id = "desc'+obj[i].cn+'">'+obj[i].c+'</a></h4><p>Domain: '+obj[i].d+'</p><p>Level: '+obj[i].l+'</p></div><div class="ratings"><button onclick="addCartClick(this)" class = "cart" type="button" id="cart'+obj[i].cn+'">Add to CART</button></div></div>');
  
      }

        }

      });

      $("#FilterButton").click(function(){
      var Domain=$('#Domain').val();
      var Course_Name=$('#Course_Name').val();
      var Level=$('#Level').val();
    
      $.ajax({url: "filter.php",

        data:{Domain:Domain , Course_Name:Course_Name,Level:Level },
        success: function(ds){

        var obj = jQuery.parseJSON( ds );

         $('#wpl').empty();

          for(var i=0 ; i < obj.length;i++)
          {
           
          $('#wpl').last().append('<div class="col-sm-4 col-lg-4 col-md-4"><div class="thumbnail"><img src="' + obj[i].i + '" alt=""><div class="caption"><h4 class="pull-right">$'+obj[i].p+'</h4><h4><a onclick="desc(this)" id = "desc'+obj[i].cn+'">'+obj[i].c+'</a></h4><p>Domain: '+obj[i].d+'</p><p>Level: '+obj[i].l+'</p></div><div class="ratings"><button onclick="addCartClick(this)" class = "cart" type="button" id="cart'+obj[i].cn+'">Add to CART</button></div></div>');
  
          }
        },

        error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    });
    });

    
    $("#mcbutton").click(function(){

        window.location.href = "mc.html";

    });

    $("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";
        localStorage.clear();

    });


    });


      function desc(element) {

          id = element.getAttribute("id").split("desc")[1];

          data = JSON.parse(localStorage.getItem('ac'));

          for(var i =0; i<data.length; i++){

            if(data[i].cn === id){

              localStorage.setItem("acc",JSON.stringify(data[i]));

            }

          }

          window.location.href = "acdesc.html";

  }

