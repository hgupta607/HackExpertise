<?php 

$Course_name = $_POST["Course_name"];
$Domain = $_POST["Domain"];


 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{
 	
	$sql1 = "SELECT * FROM FinalProject.Courses WHERE Course_Name = '$Course_name'";
	$result1 = $conn->query($sql1);
	$data = array();
	
	$row = mysqli_fetch_array($result1);

	$Course_Number = $row['Course_Number'];
	

      $sql2 = "SELECT Question_Number, Question_Text FROM FinalProject.Quiz WHERE Course_Number = '$Course_Number' AND Domain = '$Domain'";
      $result2 = $conn->query($sql2);

      if ($result2->num_rows > 0) {
		
		//loop through the result
		while($row = mysqli_fetch_array($result2))
		{	
			$ques = array();
			$Option = array();
			$AnsBitBool = array();
			$QuestionNum = $row['Question_Number'];
			$QuestionText = $row['Question_Text'];

		   	$sql3 = "SELECT Options_value, Answer FROM FinalProject.Solution WHERE Course_Number = '$Course_Number' AND Question_Number = '$QuestionNum'";
	      		
	      	$result3 = $conn->query($sql3); 
	      	while($row1= mysqli_fetch_array($result3))
			{	
				array_push($Option , $row1['Options_value']);

				$AnsBit = $row1['Answer'];

		    	if($AnsBit === '1')
				{	
					array_push($AnsBitBool, "checked");
				}
				else{
					array_push($AnsBitBool, "");
				 } 
			}

			$ques = array(
			'i' => $QuestionNum,
		    'Q' => $QuestionText,
	        'O1' => $Option[0],
	        'O2' => $Option[1],
	        'O3' => $Option[2],
	        'O4' => $Option[3],
	        'O1Check' => $AnsBitBool[0],
	        'O2Check' => $AnsBitBool[1],
	        'O3Check' => $AnsBitBool[2],
	        'O4Check' => $AnsBitBool[3]
	    	);


			array_push($data,$ques);
		}

	}

	$jsondata = json_encode($data);
	echo $jsondata;  
 	
 	$conn->close();
 }
 
?>