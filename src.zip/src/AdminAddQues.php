<?php 

$Course_name = $_POST["Course_name"];
$Domain = $_POST["Domain"];
$QuestionText = $_POST["QuestionText"];
$Option = array($_POST["Option1"], $_POST["Option2"], $_POST["Option3"], $_POST["Option4"]);
// $Option[1] = $_POST["Option1"];
// $Option[2]= $_POST["Option2"];
// $Option[3]= $_POST["Option3"];
// $Option[4] = $_POST["Option4"];
$Answer= $_POST["Answer"];
$AnsBit = array();
$AnsBitBool = array();

for($i=0; $i<4 ; $i++) {

	if($Option[$i] === $Answer)
	{	
		array_push($AnsBit, 1);
		array_push($AnsBitBool, "checked");
	}
	else{
		array_push($AnsBit, 0);
		array_push($AnsBitBool, "");
	}
}

 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{
 
	
	$sql = "SELECT * FROM FinalProject.Courses WHERE Course_Name = '$Course_name'";
	$result = $conn->query($sql);
	
	$row = mysqli_fetch_array($result);

	$Course_Number = $row['Course_Number'];
	
	
	//Query and get the question number first
 	$sql2 = "INSERT INTO FinalProject.Quiz (Course_Number,Domain,Question_Text) VALUES ('$Course_Number','$Domain','$QuestionText')";
 	if ($conn->query($sql2) === TRUE) {

      $sql3 = "SELECT * FROM FinalProject.Quiz WHERE Course_Number = '$Course_Number' AND Domain = '$Domain' AND Question_Text = '$QuestionText'";
      $result = $conn->query($sql3);
	  $row = mysqli_fetch_array($result);
	  $Question_Number = $row['Question_Number'];
	  #echo $Question_Number;
	  $sql4 = "INSERT INTO FinalProject.Solution (Question_Number,Course_Number,Options_value,Answer) VALUES ('$Question_Number','$Course_Number','$Option[0]','$AnsBit[0]'), ('$Question_Number','$Course_Number','$Option[1]','$AnsBit[1]'), ('$Question_Number','$Course_Number','$Option[2]','$AnsBit[2]'), ('$Question_Number','$Course_Number','$Option[3]','$AnsBit[3]')";
	  if ($conn->query($sql4) === TRUE){
		#echo "New Question created";
		$data = array(
			'i' => $Question_Number,
		    'Q' => $QuestionText,
	        'O1' => $Option[0],
	        'O2' => $Option[1],
	        'O3' => $Option[2],
	        'O4' => $Option[3],
	        'O1Check' => $AnsBitBool[0],
	        'O2Check' => $AnsBitBool[1],
	        'O3Check' => $AnsBitBool[2],
	        'O4Check' => $AnsBitBool[3]
	    	);

		$jsondata = json_encode($data);
		echo $jsondata;

	   }
  	} 
  	else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  	}
  	
 	$conn->close();
 }
 
?>