<?php

$user=$_GET['userid'];
$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$res_row1=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);


$result=$db->prepare("select c.domain domain, c.course_name cname,c.course_number cno,c.level level, c.price price
from courses c, Course_Register r
where r.username='$user' and c.course_number = r.Course_Number and r.payment_status=0;");
$result->execute();
while($row=$result->fetch())
{


	$res2=array("domain"=>$row['domain'],"cname"=>$row['cname'],"cno"=>$row['cno'],"level"=>$row['level'],"price"=>$row['price']);
	$res_row1[]=$res2;
}
echo json_encode($res_row1);

?>