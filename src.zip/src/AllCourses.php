<?php
$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);

$result=$db->prepare("Select * from courses;");
$result->execute();
while($row=$result->fetch())
{


	$res=array("cn"=>$row['Course_Number'],"d"=>$row['Domain'],"c"=>$row['Course_Name'],"l"=>$row['Level'],"i"=>$row['Image'],"p"=>$row['Price']);
	$res_row[]=$res;
}
echo json_encode($res_row);

?>