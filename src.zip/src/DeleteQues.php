<?php 

$Course_name = $_POST["Course_name"];
$Domain = $_POST["Domain"];
$QuestionText = $_POST["QuestionText"];
$QuestionNum = $_POST["QuestionNum"];
$Option = array($_POST["Option1"], $_POST["Option2"], $_POST["Option3"], $_POST["Option4"]);


 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{
 
	
	$sql = "SELECT * FROM FinalProject.Courses WHERE Course_Name = '$Course_name'";
	$result = $conn->query($sql);
	
	$row = mysqli_fetch_array($result);

	$Course_Number = $row['Course_Number'];
	
	
	//Query and get the question number first
 	$sql2 = "DELETE FROM FinalProject.Quiz WHERE Course_Number ='$Course_Number' AND Domain ='$Domain' AND Question_Number= '$QuestionNum' AND Question_Text = '$QuestionText'";
 	if ($conn->query($sql2) === TRUE) {

      $sql3 = "DELETE FROM FinalProject.Solution WHERE Course_Number = '$Course_Number' AND Question_Number = '$QuestionNum' ";
      $result = $conn->query($sql3);

	  if ($conn->query($sql3) === TRUE){
		echo "Question Deleted";

	   }
  	} 
  	else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  	}
  	
 	$conn->close();
 }
 
?>