$(document).ready(function(){

    $("#addNewCourse").click(function(){

      window.location.href = 'AdminAddItem.html';
      
   });

});