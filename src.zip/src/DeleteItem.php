<?php
$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$CourseNumber=$_POST['CourseNum'];
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);

$result0=$db->prepare("SELECT * FROM Course_Register WHERE Course_Number='$CourseNumber';");
$result0->execute();

echo $result0->num_rows;

if($result0->rowCount() > 0){

	echo "The Course cannot be deleted. A user is registered";
}
else{

$result1=$db->prepare("DELETE FROM Courses WHERE Course_Number=$CourseNumber;");
$result1->execute();

$result3=$db->prepare("DELETE FROM Quiz WHERE Course_Number=$CourseNumber;");
$result3->execute();

$result4=$db->prepare("DELETE FROM Solution WHERE Course_Number=$CourseNumber;");
$result4->execute();

echo "The course has been deleted";

}

?>