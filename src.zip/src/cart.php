<?php

$user=$_GET['user'];


$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);


$result=$db->prepare("SELECT  Course_Number FROM Course_Register WHERE username='$user' and Payment_status=0;");
$result->execute();
$count=0;
while($row=$result->fetch())
{

	$count+=1;
	$res=array("cnum"=>$row['Course_Number']);
	$res_row[]=$res;
}
if($count == 0)
{
$f1=[];
$f2=array("cnum"=>"no");
$f1[]=$f2;
$f3=array("cnum"=>"no");
$f1[]=$f3;
echo json_encode($f1);
}
else
{
echo json_encode($res_row);
}

?>