$(document).ready(function(){
  $("#NewCourse").submit(function() {
   $.ajax({
    url: 'AdminAddItem.php',
    type: 'POST',
    data: {
      Course_name: $('#Course_name').val(),
  	  Domain:$('#Domain').val(),
  	  ImageLink: $('#ImageLink').val(),
 	    Level: $('#Level').val(),
  	  Price: $('#Price').val(),
      Time: $('#Time').val(),
      Description: $('#Description').val()
    },
    success: function(response) { 
    	alert(response);
      window.location.href = "AllCoursesAdmin.html";

     },
     error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    });
 });

    $("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";
        localStorage.clear();

    });

      $("#CancelAdd").click(function(){

        window.location.href = "AllCoursesAdmin.html";

    });

});