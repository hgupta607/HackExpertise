<?php
$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$user=$_POST['username'];
$p = 1;
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);

$result=$db->prepare("SELECT * FROM Courses,Course_Register WHERE Courses.Course_Number =Course_Register.Course_Number AND Course_Register.Username='$user' AND Course_Register.Payment_status = '$p' AND Course_Register.Reg_Id NOT IN(SELECT Test_Result.Reg_Id FROM Test_Result)");
$result->execute();
while($row=$result->fetch())
{
	$res=array("cn"=>$row['Course_Number'],"d"=>$row['Domain'],"c"=>$row['Course_Name'],"l"=>$row['Level'],"i"=>$row['Image'],"p"=>$row['Price'],"t"=>$row['Time'],"ds"=>$row['Description'],"regid"=>$row['Reg_Id']);
	$res_row[]=$res;
}
echo json_encode($res_row);

?>