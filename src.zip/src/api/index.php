<?php 

$conn = mysqli_connect("localhost", "root", "root");

// Check connection
 if (!$conn) {
 	echo "no connection";
 }
else {

	$url = $_SERVER['REQUEST_URI']; 
	$str = substr($url, strrpos($url, '/') + 1);
	if($str == "books"){

  	$sql = "SELECT * FROM test.Book";
	$result = $conn->query($sql);
	$books = array(); 
	if ($result->num_rows > 0) {
		
		//loop through the result
		while($row = mysqli_fetch_array($result))
		{	
			array_push($books,$row['title'] );

		}
			$jsonstring = json_encode($books);
		}
	}
	else{
		$authors=array();
		$id = $str;
		  	$sql = "SELECT * FROM test.Book, test.Book_Authors, test.Authors WHERE Book.Book_id = $id AND Book.Book_id=Book_Authors.Book_id AND Book_Authors.Author_id=Authors.Author_id ";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				while($row = mysqli_fetch_array($result))
				{	
					$book = array( 'title' => $row['title'],'year' => $row['year'],'price' => $row['price'],
			        'category' => $row['category']);
			        array_push($authors, $row['Author_Name']);
				}
			}
			$res = array('Book'=>$book,'Author' => $authors);  
			$jsonstring = json_encode($res);

	}
		echo $jsonstring;
		$conn->close();
 
} 


?>