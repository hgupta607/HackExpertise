<?php 

// Create connection
$conn = mysqli_connect("localhost", "root", "root");


// Check connection
 if (!$conn) {
 	echo "no connection";
 }
else {
	echo "Hii";

  	$sql = "SELECT * FROM test.Book AS B test.Book-Authors AS BA test.Authors AS A where B.Book-id = '1' AND B.Book-id = BA.Book-id AND BA.Author-id = A.Author-id";
	$result = $conn->query($sql);
	$books = array();
	if ($result->num_rows > 0) {
		
		//loop through the result
		// while($row = mysqli_fetch_array($result))
		// {
		// 	$book = array( 'Book-id' => $row['book-id'], 'title' => $row['title'],'year' => $row['year'],'price' => $row['price'],
	 //        'category' => $row['category']);
	
		// 	array_push($books, $book);

		// }
	}  
	$jsonstring = json_encode($result);
		echo $jsonstring;
		$conn->close();
 
} 


?>