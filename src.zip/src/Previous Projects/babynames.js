$(document).ready(function(){
  $("#myForm").submit(function() {
    $("#girltable tbody").remove();
    $("#boytable tbody").remove();
   $.ajax({
    url: 'babynames.php',
    type: 'POST',
    data: {
      year: $('#year').val()
    },
    success: function(response) { 
        data = JSON.parse(response);
        for(i=0; i<5;i++){
            b_name = data.boy[i].name;
            b_ranking = data.boy[i].ranking;
            $('#boytable').last().append('<tr><td>'+b_name+'</td><td>'+b_ranking+'</td></tr>');

            g_name = data.girl[i].name;
            g_ranking = data.girl[i].ranking;
            $('#girltable').last().append('<tr><td>'+g_name+'</td><td>'+g_ranking+'</td></tr>');
        }
     },
     error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    });
 });
});