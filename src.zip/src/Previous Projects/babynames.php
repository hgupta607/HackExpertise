<?php 

$year = $_POST["year"];

// Create connection
$conn = mysqli_connect("localhost", "root", "root");

// Check connection
 if (!$conn) {
 }
 else{
 	$sql = "SELECT * FROM Baby_Names.BabyNames WHERE year = '$year' ORDER BY ranking";
	$result = $conn->query($sql);
	$boy = array();
	$girl = array();
	if ($result->num_rows > 0) {
		
		//loop through the result
		while($row = mysqli_fetch_array($result))
		{
			$names = array(
		    'name' => $row['name'],
	        'year' => $row['year'],
	        'ranking' => $row['ranking'],
	        'gender' => $row['gender']
	    	);
		   if($row['gender'] == 'm'){
	    	array_push($boy, $names);
	    	}
	    	else if($row['gender'] == 'f'){
	    	array_push($girl, $names);
	    	}
		}
	}  
		$json = array(
	        'boy' => $boy,
	        'girl' => $girl,
	    	);
		$jsonstring = json_encode($json);
		echo $jsonstring;
		$conn->close(); 
} 

?> 
