<?php 

$conn = mysqli_connect("localhost", "root", "root");

// Check connection
 if (!$conn) {
 }
 else{
 	$username = $_COOKIE["username"];
 	$sql = "SELECT * FROM test.users WHERE username = '$username'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
        $fullname = $row["fullname"];
        $email = $row["email"];
        $power_animal = $row["power_animal"];
    	}
	} else {
	  
	}
}

$conn->close();	

if (isset($_COOKIE["pagevisit"])) {
   $number = $_COOKIE["pagevisit"];
   $number = $number + 1;
   setcookie("pagevisit", $number);
 } 
 else {
  setcookie("pagevisit", 1);
  $number = 1;
}

print("Username: $username");
echo "<br><br>";
print("Fullname: $fullname");
echo "<br><br>";
print("Email: $email");
echo "<br><br>";
print("Power Animal:");
echo "<br>";
echo "<img src='images/$power_animal' style='height:200px;width:200px;'>";
echo "<br><br>";
print("No. of visits : $number");

?>