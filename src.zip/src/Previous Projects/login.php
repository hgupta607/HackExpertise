<?php 

$fullname = $email = $username = "";

// check if the cookie is set
 if (isset($_COOKIE["username"])) {
   $username = $_COOKIE["username"];
   if(DBConnection($username)){
	    header("Location: welcome.php");
		die();
  }
 } 
 else {
  $fullname = $_POST["fullname"];
  $email = $_POST["email"];
  $username = $_POST["username"];

  //if all fields are nt filled redirect to login page
  if($fullname == "" || $email == "" || $username == ""){
  		header("Location: login.html");
  		die();
  		
  }
  else{
	  if(DBConnection($username)){
	  		setcookie("username", $username);
		    header("Location: welcome.php");
			die();
	  }
	  else{
	  	echo "<p>User should sign in</p>";
	  	echo "<a href='login.html'>Login page</a>";

	  }
  }
}

function DBConnection($username) {
// Create connection
$conn = mysqli_connect("localhost", "root", "root");

// Check connection
 if (!$conn) {
 }
 else{

 	$sql = "SELECT * FROM test.users WHERE username = '$username'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		$conn->close();
		return 1;	
	} else {
	    $conn->close();
	    return 0;
	}
}

}

?> 
