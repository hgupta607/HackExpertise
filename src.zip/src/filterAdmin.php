<?php
$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";

$Domain=$_GET['Domain'];
$Course_Name=$_GET['Course_Name'];
$Level=$_GET['Level'];
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);

//Domain is empty
if($Domain == ""){
	//Course name is empty
	if($Course_Name == ""){
		//all are empty
		if($Level == ""){

			$result=$db->prepare("Select * from courses");

		}
		//Only level
		else{

			$result=$db->prepare("Select * from courses where Level = '$Level';");

		}

	}
	//Domain is empty ,coursename is not
	else{

		//Only course
		if($Level == ""){

			$result=$db->prepare("Select * from courses where lower(Course_Name) like lower('%$Course_Name%');");
		}
		//Only level and course
		else{

			$result=$db->prepare("Select * from courses where lower(Course_Name) like lower('%$Course_Name%') AND Level = '$Level';");

		}
	}	

}
else{

	//Course name is empty
	if($Course_Name == ""){
		//only Domain
		if($Level == ""){

			$result=$db->prepare("Select * from courses where lower(Domain) like lower('%$Domain%');");
		}
		//Only level and Domain
		else{

			$result=$db->prepare("Select * from courses where lower(Domain) like lower('%$Domain%') AND Level = '$Level';");
		}

	}
	else{

		//Only Domain and Course
		if($Level == ""){

			$result=$db->prepare("Select * from courses where lower(Domain) like lower('%$Domain%') AND lower(Course_Name) like lower('%$Course_Name%');");

		}
		//Domain and level and course
		else{

			$result=$db->prepare("Select * from courses where lower(Domain) like lower('%$Domain%') AND lower(Course_Name) like lower('%$Course_Name%') AND Level = '$Level';");
		}
	}	
}

//$result=$db->prepare("Select * from courses where Domain = '$Domain' AND Course_Name = '$Course_Name' AND Level = '$Level';");
$result->execute();
while($row=$result->fetch())
{

	$res=array("cn"=>$row['Course_Number'],"d"=>$row['Domain'],"c"=>$row['Course_Name'],"l"=>$row['Level'],"i"=>$row['Image'],"p"=>$row['Price']);
	$res_row[]=$res;
}
echo json_encode($res_row);

?>