$(document).ready(function(){
	
    $('#LoggedIn').text(localStorage.getItem("UserLoggedIn"));
      //For course registered
      $.ajax({url: "mc.php",
      type: 'POST',
        data: {
          username: localStorage.getItem("UserLoggedIn")
        },
      success: function(ds){
      var obj = jQuery.parseJSON( ds );

      localStorage.setItem('TakeTestCourses', ds);

      for(var i=0 ; i < obj.length;i++)
      {
       
	   $('#wpl1').last().append('<div class="col-sm-4 col-lg-4 col-md-4"><div class="thumbnail"><img src="' + obj[i].i + '" alt=""><div class="caption"><h4 class="pull-right">$'+obj[i].p+'</h4><h4>'+obj[i].c+'</h4><p>Domain: '+obj[i].d+'</p><p>Level: '+obj[i].l+'</p><button onclick="TakeTest(this)" id="taketest'+obj[i].cn+'">Take Test</button</div><div class="ratings"></div></div>');
  
      }

        }

      });

      //For course completed
      $.ajax({url: "mc1.php",
        type: 'POST',
        data: {
          username: localStorage.getItem("UserLoggedIn")
        },
      success: function(ds){
      var obj = jQuery.parseJSON( ds );

      //localStorage.setItem('AllCourses', ds);

      for(var i=0 ; i < obj.length;i++)
      {
       
     $('#wpl11').last().append('<div class="col-sm-4 col-lg-4 col-md-4"><div class="thumbnail"><img src="' + obj[i].i + '" alt=""><div class="caption"><h4 class="pull-right">$'+obj[i].p+'</h4><h4>'+obj[i].c+'</h4><p>Domain: '+obj[i].d+'</p><p>Level: '+obj[i].l+'</p><p>Result: '+obj[i].r+'%</p></div><div class="ratings"></div></div>');
  
      }

        }

      });

      //logout
    $("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";
        localStorage.clear();

    });

    $("#findcourses").click(function() {
      window.location.href = 'ac.html';
    });

    });


  function TakeTest(element) {

          id = element.getAttribute("id").split("taketest")[1];

          data = JSON.parse(localStorage.getItem('TakeTestCourses'));

          for(var i =0; i<data.length; i++){

            if(data[i].cn === id){

              localStorage.setItem("currentTest",JSON.stringify(data[i]));

            }

          }

          window.location.href = "taketest.html";

  }


