<?php

$cnum=$_GET['cnum'];
$domain=$_GET['domain'];

$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);


$result=$db->prepare("select q.question_number as qno,q.Question_Text as qtext,s.answer as ans,s.Options_value as opt
from quiz q  join Solution s
where q.course_number = s.Course_Number and q.question_number=s.Question_Number
and  q.Domain='$domain' and q.Course_Number='$cnum' ORDER BY q.question_number;
");
$result->execute();
while($row=$result->fetch())
{


	$res=array("qno"=>$row['qno'],"qtext"=>$row['qtext'],"ans"=>$row['ans'],"opt"=>$row['opt']);
	$res_row[]=$res;
}
echo json_encode($res_row);

?>