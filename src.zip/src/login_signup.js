$(document).ready(function(){

  localStorage.setItem("ErrorState","false");

  $("#NewUser").submit(function() {

    if($('#Firstname').val()=="" || $('#Lastname').val()== "" || $('#Username').val()=="" || $('#Email').val()=="" || $('#Password').val()=="" || localStorage.getItem("ErrorState")=="true"){
      alert("Enter all required fields correctly");
    }
    else{
       $.ajax({
        url: 'login_signup.php',
        type: 'POST',
        data: {
          Firstname: $('#Firstname').val(),
      	  Lastname:$('#Lastname').val(),
      	  Username: $('#Username').val(),
     	    Email: $('#Email').val(),
      	  password: $('#Password').val()
        },
        success: function(response) { 
        	alert(response);
          $( "#NewUser").each(function(){
              this.reset();
          });

         },
         error: function(request,status,errorThrown) {
             alert(status);
             alert(errorThrown);
             alert(request);
         }
        });
      }
     });

  $("#UserLogin").submit(function() {
    if($('#EmailLogin').val()=="" || $('#PasswordLogin').val()==""){
      alert("Enter all required fields");
    }
    else{
       $.ajax({
        url: 'login.php',
        type: 'POST',
        data: {
          Email: $('#EmailLogin').val(),
          password: $('#PasswordLogin').val()
        },
        success: function(response) { 
          $("#UserLogin").each(function(){
              this.reset();
          });
          var res = JSON.parse(response);

          if(res[0] === "0"){

            alert(res[1]);
          }
          else if(res[0] === "1"){

            localStorage.setItem("AdminLoggedIn", "true");
            window.location.href = "AllCoursesAdmin.html";

          }
          else if(res[0] === "2"){

            alert(res[1]);
            localStorage.setItem("UserLoggedIn", res[2]);
            window.location.href = "mc.html";

          }

         },
         error: function(request,status,errorThrown) {
             alert(status);
             alert(errorThrown);
             alert(request);
         }
        });
     }
 });

  $("#Username").blur(function(){

    var value1 = $("#Username").val();

    if(value1 == ""){
      $(this).addClass("error");
      localStorage.setItem("ErrorState","true");
    }
    else{
      var regex1 = /^[a-zA-Z]*$/;
    
        if (regex1.test(value1)) {

        $(this).removeClass("error");
        localStorage.setItem("ErrorState","false");

        }
        else{

          $(this).addClass("error");
          localStorage.setItem("ErrorState","true");
        }
      }
    
  });

    $("#Firstname").blur(function(){

    var value2 = $("#Firstname").val();

    if(value2 == ""){
      $(this).addClass("error");
      localStorage.setItem("ErrorState","true");
    }
    else{
      var regex2 = /^[a-zA-Z]*$/;
    
        if (regex2.test(value2)) {

        $(this).removeClass("error");
        localStorage.setItem("ErrorState","false");

        }
        else{

          $(this).addClass("error");
          localStorage.setItem("ErrorState","true");
        }
      }
    
  });

    $("#Lastname").blur(function(){

    var value3 = $("#Lastname").val();

    if(value3 == ""){
      $(this).addClass("error");
      localStorage.setItem("ErrorState","true");
    }
    else{
      var regex3 = /^[a-zA-Z]*$/;
    
        if (regex3.test(value3)) {

        $(this).removeClass("error");
        localStorage.setItem("ErrorState","false");

        }
        else{

          $(this).addClass("error");
          localStorage.setItem("ErrorState","true");
        }
      }
    
  });

  $("#Email").blur(function(){

    var value4 = $("#Email").val();

    if(value4 == ""){
      $(this).addClass("error");
      localStorage.setItem("ErrorState","true");
    }
    else{
      
      var regex4 = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
    
        if (regex4.test(value4)) {

            $(this).removeClass("error");
            localStorage.setItem("ErrorState","false");
        }
        else{

            $(this).addClass("error");
            localStorage.setItem("ErrorState","true");
        }
      }

  });

  $("#Password").blur(function(){

    var value5 = $("#Password").val();

    if(value5 == ""){
      $(this).addClass("error");
      localStorage.setItem("ErrorState","true");
    }
    else{

        var regex5 =  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{4,8}$/;
    
        if (regex5.test(value5)) {

            $(this).removeClass("error");
            localStorage.setItem("ErrorState","false");
        }
        else{

            $(this).addClass("error");
            localStorage.setItem("ErrorState","true");
        }
    }

  });

 $("#EmailLogin").blur(function(){

    var value6 = $("#EmailLogin").val();

    if(value6 == ""){
      $(this).addClass("error");
    }
    else{
      
      var regex6 = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
    
        if (regex6.test(value6)) {

            $(this).removeClass("error");
        }
        else{

            $(this).addClass("error");
        }
      }

  });

  $("#PasswordLogin").blur(function(){

    var value7 = $("#PasswordLogin").val();

    if(value7 == ""){
      $(this).addClass("error");
    }
    else{

        $(this).removeClass("error");
    }
    
  });



});