$(document).ready(function(){

   $('#LoggedIn').text(localStorage.getItem("UserLoggedIn"));

var userid=localStorage.getItem("UserLoggedIn");
localStorage.setItem("userid",userid);
display(userid);

$("#deleteall").click(function(){

 var userid=localStorage.getItem("userid");
 $.ajax({url: "delete_all_from_cart.php",data:{userid:userid},
 success: function(delet){
window.location.href = 'ac.html';

 }
});
});

$("#checkout").click(function(){

 var userid=localStorage.getItem("userid");
 $.ajax({url: "checkout.php",data:{userid:userid},
 success: function(check){
alert("Courses Successsfully Purchased");
window.location.href = 'mc.html';

 }
});

});


    $("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";
        localStorage.clear();

    });
});

function deleteme(x) {
var userid=localStorage.getItem("userid");
var cnum= x.getAttribute("id");


 $.ajax({url: "deletefromcart.php",data:{cnum:cnum,userid:userid},
 success: function(del){

  display(userid);

}
});




}

function display(userid){

 $.ajax({url: "displaycart.php",data:{userid:userid},dataType: "json",
 success: function(cartde){
if(cartde.length!=0)
{
     $('#cart table tr:not(:first)').remove();
for(var i=0;i<cartde.length;i++)
{
$('#cartinfo').last().append('<tr><td>'+cartde[i].domain+'</td><td>'+cartde[i].cname+'</td><td>'+cartde[i].level+'</td><td>'+cartde[i].price+'</td><td><button onclick="deleteme(this)" class="deleteme" id="'+cartde[i].cno+'"> Delete</button></td></tr>');
}
}
else
{
window.location.href = 'ac.html';
}
}
});
}


