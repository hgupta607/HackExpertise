<?php 
  $course_num = $_POST["Course_number"];
  $course_name = $_POST["Course_name"];
   $domain = $_POST["Domain"];
   $link = $_POST["ImageLink"];
   $level = $_POST["Level"];
   $price = $_POST["Price"];
 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{

 	$sql = "UPDATE FinalProject.Courses SET Course_Name='$course_name',Domain='$domain',Image='$link',Level='$level',Price='$price' WHERE Course_Number = $course_num";
 	if ($conn->query($sql) === TRUE) {
      echo "Record Edited created successfully";
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }
 	$conn->close();
 }

?>
