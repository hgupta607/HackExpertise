$(document).ready(function(){

if (localStorage.getItem("UserLoggedIn") !== null) {

var user=localStorage.getItem("UserLoggedIn");
var cart_qty = 0;
var cart_items = [];
localStorage.setItem("cart_qty",cart_qty);

$("#qty").hide();

cart_info = $.ajax({type:'GET',url: "cart.php",dataType: "json",data:{user:user}}); 
	
	
cart_info.done( function(cart_i) {
if(cart_i[0].cnum!="no")
{
 cart_qty = cart_i.length;
 cart_items = [];

for(var i=0;i<cart_i.length;i++)
{
cart_items.push(cart_i[i].cnum);
}

localStorage.setItem("cart_qty",cart_qty);
localStorage.setItem("cart_items",JSON.stringify(cart_items));
   $("#qty").text(cart_qty);
$("#qty").show();
}

});

}

$("#cartimg").click(function(){
window.location.href = "cartdetails.html";

});

});

function addCartClick(element){

if (localStorage.getItem("UserLoggedIn") === null) {

   alert("You must be logged in to continue");
   window.location.href = "login.html";
}   
else{
var cnum= element.getAttribute("id").split("cart")[1];
var user=localStorage.getItem("UserLoggedIn");

$.ajax({url: "CourseActive.php",data:{user:user,cnum:cnum},
 success: function(response){

   if(response === "true"){
   alert("Course is already purchased.Proceed to test");
}
else{
var cq=parseInt(localStorage.getItem("cart_qty"));

         if(cq ==0)
         {
         addcart(user,cnum);
         
         var ci=[];

                  cq=cq+1;
               ci.push(cnum) ;
               
               localStorage.setItem("cart_qty",cq);
               localStorage.setItem("cart_items",JSON.stringify(ci));
               $("#qty").text(cq);
            $("#qty").show();


         }
         else
         {

            var ci=JSON.parse(localStorage.getItem("cart_items"));
var addedflag = 0;
for (var i=0;i<ci.length;i++)
         {
            if(jQuery.inArray(cnum,ci)==-1)
            {
                     addcart(user,cnum);
                     addedflag =1;
                  cq=cq+1;
               ci.push(cnum) ;
                  localStorage.setItem("cart_qty",cq);
               localStorage.setItem("cart_items",JSON.stringify(ci));
                  $("#qty").text(cq);
               $("#qty").show();

            }

         }
         if(addedflag == 0){
            alert("Course already added to cart");
         }
}
}
 }
});



}
};

function addcart(user,cnum)
{
   		$.ajax({url: "addtocart.php",
   		data:{user:user,cnum:cnum},
   		success: function(ds){
   		
   		
   		},
   		error: function () {
   		
   		alert("did not add");
   		}
   		});
   		
}


