$(document).ready(function(){
    	
        $.ajax({url: "AllCourses.php",success: function(ds){
      var obj = jQuery.parseJSON( ds );

      for(var i=0 ; i < obj.length;i++)
      {
       
	   $('#wpl').last().append('<div class="col-sm-4 col-lg-4 col-md-4"><div class="thumbnail"><img src="' + obj[i].i + '" alt=""><div class="caption"><h4 class="pull-right">'+obj[i].p+'</h4><h4><a href="#">'+obj[i].c+'</a></h4><p>Domain: '+obj[i].d+'</p><p>Level: '+obj[i].l+'</p></div><div class="ratings"><button type="button">Enroll</button></div></div>');
  
      }


        }

        });
    });

