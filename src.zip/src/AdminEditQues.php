<?php 

$Course_name = $_POST["Course_name"];
$Domain = $_POST["Domain"];
$QuestionText = $_POST["QuestionText"];
$QuestionNum = $_POST["QuestionNum"];
$Option = array($_POST["Option1"], $_POST["Option2"], $_POST["Option3"], $_POST["Option4"]);
$Answer= $_POST["Answer"];
$AnsBit = array();
$AnsBitBool = array();

for($i=0; $i<4 ; $i++) {

	if($Option[$i] === $Answer)
	{	
		array_push($AnsBit, 1);
		array_push($AnsBitBool, "checked");
	}
	else{
		array_push($AnsBit, 0);
		array_push($AnsBitBool, "");
	}
}

 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{
 
	
	$sql = "SELECT * FROM FinalProject.Courses WHERE Course_Name = '$Course_name'";
	$result = $conn->query($sql);
	
	$row = mysqli_fetch_array($result);

	$Course_Number = $row['Course_Number'];
	

 	$sql2 = "UPDATE FinalProject.Quiz SET Question_Text = '$QuestionText' WHERE Course_Number ='$Course_Number' AND Domain ='$Domain' AND Question_Number = '$QuestionNum'";
 	if ($conn->query($sql2) === TRUE) {

      $sql3 = "DELETE FROM FinalProject.Solution WHERE Course_Number = '$Course_Number' AND Question_Number = '$QuestionNum' ";
      $result = $conn->query($sql3);

	  #echo $Question_Number;
	  $sql4 = "INSERT INTO FinalProject.Solution (Question_Number,Course_Number,Options_value,Answer) VALUES ('$QuestionNum','$Course_Number','$Option[0]','$AnsBit[0]'), ('$QuestionNum','$Course_Number','$Option[1]','$AnsBit[1]'), ('$QuestionNum','$Course_Number','$Option[2]','$AnsBit[2]'), ('$QuestionNum','$Course_Number','$Option[3]','$AnsBit[3]')";
	  if ($conn->query($sql4) === TRUE){
		#echo "Question updated";
		$data = array(
			'i' => $QuestionNum,
		    'Q' => $QuestionText,
	        'O1' => $Option[0],
	        'O2' => $Option[1],
	        'O3' => $Option[2],
	        'O4' => $Option[3],
	        'O1Check' => $AnsBitBool[0],
	        'O2Check' => $AnsBitBool[1],
	        'O3Check' => $AnsBitBool[2],
	        'O4Check' => $AnsBitBool[3]
	    	);

		$jsondata = json_encode($data);
		echo $jsondata;

	   }
  	} 
  	else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  	}
  	
 	$conn->close();
 }
 
?>