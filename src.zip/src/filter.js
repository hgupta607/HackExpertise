$(document).ready(function(){

    $("button").click(function(){
    	var Domain=$('#Domain').val();
  		var Course_Name=$('#Course_Name').val();
  		var Level=$('#Level').val();
		
  		$.ajax({url: "filter.php",

        data:{Domain:Domain , Course_Name:Course_Name,Level:Level },
        success: function(ds){

    		var obj = jQuery.parseJSON( ds );

         $('#wpl').empty();

          for(var i=0 ; i < obj.length;i++)
          {
           
    	   $('#wpl').last().append('<div class="col-sm-4 col-lg-4 col-md-4"><div class="thumbnail"><img src="' + obj[i].i + '" alt=""><div class="caption"><h4 class="pull-right">'+obj[i].p+'</h4><h4><a href="#">'+obj[i].c+'</a></h4><p>'+obj[i].d+'</p><p> '+obj[i].l+'</p></div><div class="ratings"><button type="button">Enroll</button></div></div>');
      
          }
        },

        error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    });
  });
});