<?php 
   $email = $_POST["Email"];
   $password = $_POST["password"];
 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{

  $sql1 = "SELECT * FROM FinalProject.Login WHERE pass = '$password' AND Email = '$email'";
  $result = $conn->query($sql1);
  $res = array();

  if ($result->num_rows > 0) {

      if($email === "admin@gmail.com"){
            array_push($res,"1");
            array_push($res,"Login Successfull"); 
        }
        else{
          array_push($res,"2");
          array_push($res,"Login Successfull");
          $row = mysqli_fetch_array($result);
          $username = $row['Username']; 
          array_push($res,$username);
        }

       
      
  } else {

      array_push($res,"0");
      array_push($res,"User does not exist"); 
          
  }

  echo json_encode($res); 
 	$conn->close();
 }

?>
