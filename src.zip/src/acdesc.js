$(document).ready(function(){

  data= JSON.parse(localStorage.getItem('acc'));

 $('#ai').last().append('<div class="col-xs-4"><img src="'+ data.i +'" alt="Course Image" style="width:304px;height:228px;"></div><div class="col-xs-8"><h1><b>'+ data.c +'</b></h1><h4><b>Domain :</b>'+ data.d +'</h4><h4><b>Level : </b>'+ data.l +'</h4><h4><b>Price : </b>$'+ data.p +'</h4><h4><b>Description : </b>'+ data.de +'</h4></div>');
      
});