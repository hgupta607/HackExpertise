<?php

$user=$_GET['user'];
$cnum=$_GET['cnum'];

$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);


$result=$db->prepare("SELECT * FROM Course_Register WHERE Course_Register.Course_Number='$cnum' AND Course_Register.Username= '$user' AND Course_Register.Payment_status = 1 
AND Course_Register.Reg_Id NOT IN(SELECT Test_Result.Reg_Id FROM Test_Result)") ;
$result->execute();
$num= $result->fetchColumn(); 
if($num>0){
	echo "true";
}
else{
	echo "false";
}

?>