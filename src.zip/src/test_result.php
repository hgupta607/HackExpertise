<?php

$percent=$_GET['percent'];
$regid=$_GET['regid'];

$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);


$result=$db->prepare("INSERT INTO Test_Result(Reg_Id,Result) VALUES ('$regid','$percent')");
$result->execute();
if($result)
echo ("Test successfully completed.");
else
echo ("Sorry test could not be saved. ");

?>