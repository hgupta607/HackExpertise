$(document).ready(function(){

  data= JSON.parse(localStorage.getItem('currentCourseEdit'));

  $('#Course_name').val(data.c);
  $('#Domain').val(data.d);
  $('#ImageLink').val(data.i);
  $('#Level').val(data.l);
  $('#Price').val(data.p);
  $('#Time').val(data.t);
  $('#Description').val(data.ds);

  $("#NewCourse").submit(function() {
   $.ajax({
    url: 'AdminEditItem.php',
    type: 'POST',
    data: {
      Course_number: data.cn,
      Course_name: $('#Course_name').val(),
  	  Domain:$('#Domain').val(),
  	  ImageLink: $('#ImageLink').val(),
 	    Level: $('#Level').val(),
  	  Price: $('#Price').val(),
      Time: $('#Time').val(),
      Description: $('#Description').val()
    },
    success: function(response) { 
    	alert(response)
      window.location.href = "AllCoursesAdmin.html";

     },
     error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    });
 });

    $("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";
        localStorage.clear();

    });

    $("#CancelEdit").click(function(){

        window.location.href = "AllCoursesAdmin.html";

    });

});