$(document).ready(function(){

$.ajax({
    url: 'DisplayQues.php',
    type: 'POST',
    data: {
      Course_name: localStorage.Course_name,
      Domain: localStorage.Domain
    },
    success: function(response) { 
      data = JSON.parse(response);
      //alert(data);

      for($j=0; $j<data.length; $j++){

        $('#Questionlist').last().append('<li id="questionitem'+data[$j].i+'"><div id="question'+data[$j].i+'"><p class="question">'+data[$j].Q+'</p><ul class="QuizList"><li><input class="rb" type="radio" name="q'+data[$j].i+'" '+data[$j].O1Check+'><label for="q1a">'+data[$j].O1+'</label></li><li><input class="rb" type="radio" name="q'+data[$j].i+'" '+data[$j].O2Check+'><label for="q1b">'+data[$j].O2+'</label></li><li><input class="rb" type="radio" name="q'+data[$j].i+'" '+data[$j].O3Check+'><label for="q1c">'+data[$j].O3+'</label></li><li><input class="rb" type="radio" name="q'+data[$j].i+'" '+data[$j].O4Check+'><label for="q1d">'+data[$j].O4+'</label></li></ul><button onclick="deleteQues(this)" id="delete'+data[$j].i+'" ><img class="editdelete delete" src="images/delete.png" alt=""></button><button onclick="showEdit(this)" class="edit" id="edit'+data[$j].i+'"><img class="editdelete" src="images/edit.png" alt=""></button></div></li>');
        $('#questionitem'+data[$j].i).last().append('<div id = "editform'+data[$j].i+'" class="editform"><form onsubmit="return false;"><input type="textarea" class="questionarea" id="QuestionText'+data[$j].i+'" value="'+data[$j].Q+'"><ul class="QuizList"><li><input class="rb" id="op1'+data[$j].i+'" value="1" name="options'+data[$j].i+'" type="radio" '+data[$j].O1Check+'><input type="text" name="option1" id="option1'+data[$j].i+'" value="'+data[$j].O1+'"></li><li><input class="rb" value="2" id="op2'+data[$j].i+'" name="options'+data[$j].i+'" type="radio" '+data[$j].O2Check+'><input type="text" name="option2" id="option2'+data[$j].i+'" value="'+data[$j].O2+'"></li><li><input class="rb" value="3" id="op3'+data[$j].i+'" name="options'+data[$j].i+'" type="radio" '+data[$j].O3Check+'><input type="text" name="option3" id="option3'+data[$j].i+'" value="'+data[$j].O3+'"></li><li><input class="rb" value="4" id="op4'+data[$j].i+'" name="options'+data[$j].i+'" type="radio" '+data[$j].O4Check+'><input type="text" name="option4" id="option4'+data[$j].i+'" value="'+data[$j].O4+'"></li></ul></form><button onclick="editSave(this)" id="Save'+data[$j].i+'">Save</button><button onclick="hideEdit(this)" class="cancel" id="Cancel'+data[$j].i+'">Cancel</button></div>');       
        $('#editform'+data[$j].i).hide();

      }

     },
     error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    }); 

   $('#Course_name').append(localStorage.Course_name);

   $('#Domain').append(localStorage.Domain);

   $("#addQuestion").click(function(){
      addQuestion();
   });

    $("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";

    });
 
});


function showEdit(element)
{   
  id = element.getAttribute("id").split("edit")[1];
  quesid = "#question"+id;
  editid = "#editform"+id;
   $(quesid).hide();
   $(editid).show();
  //$(editid).css({"visibility":"visible","display":"block"});
  //$(quesid).css({"visibility":"hidden"});
}

function hideEdit(element)
{   
   id = element.getAttribute("id").split("Cancel")[1];
   quesid = "#question"+id;
   editid = "#editform"+id; 
   $(quesid).show();
   $(editid).hide();
   //$(quesid).css({"visibility":"visible","display":"block"});
   //$(editid).css({"visibility":"hidden"}); 
   
}

function editSave(element)
{   
   id = element.getAttribute("id").split("Save")[1];
   quesitemid = "#questionitem"+id; 
   editid = "#editform"+id;
   $input = "input[name=options"+id+"]:checked";
  // $(quesid).css({"visibility":"visible","display":"block"});
   //$(editid).css({"visibility":"hidden"});

  op = $($input).val();
  ans = "#option"+op+id;
  $.ajax({
    url: 'AdminEditQues.php',
    type: 'POST',
    data: {
      Course_name: localStorage.Course_name,
      Domain: localStorage.Domain,
      QuestionNum: id,
      QuestionText:$('#QuestionText'+id).val(),
      Option1: $('#option1'+id).val(),
      Option2: $('#option2'+id).val(),
      Option3: $('#option3'+id).val(),
      Option4: $('#option4'+id).val(),
      Answer: $(ans).val()

    },
    success: function(response) { 
      alert("Question edited successfully");
      data = JSON.parse(response);
      $(quesitemid).empty();
      //$(editid).remove();
      //i=1;
      $(quesitemid).last().append('<div id="question'+data.i+'"><p class="question">'+data.Q+'</p><ul class="QuizList"><li><input class="rb" type="radio" name="q'+data.i+'" '+data.O1Check+'><label for="q1a">'+data.O1+'</label></li><li><input class="rb" type="radio" name="q'+data.i+'" '+data.O2Check+'><label for="q1b">'+data.O2+'</label></li><li><input class="rb" type="radio" name="q'+data.i+'" '+data.O3Check+'><label for="q1c">'+data.O3+'</label></li><li><input class="rb" type="radio" name="q'+data.i+'" '+data.O4Check+'><label for="q1d">'+data.O4+'</label></li></ul><button onclick="deleteQues(this)" id="delete'+data.i+'" ><img class="editdelete delete" src="images/delete.png" alt=""></button><button onclick="showEdit(this)" class="edit" id="edit'+data.i+'"><img class="editdelete" src="images/edit.png" alt=""></button></div>');
      $('#questionitem'+data.i).last().append('<div id = "editform'+data.i+'" class="editform"><form onsubmit="return false;"><input type="textarea" class="questionarea" id="QuestionText'+data.i+'" value="'+data.Q+'"><ul class="QuizList"><li><input class="rb" value="1" name="options'+data.i+'" type="radio" '+data.O1Check+'><input type="text" name="option1" id="option1'+data.i+'" value="'+data.O1+'"></li><li><input class="rb" value="2" name="options'+data.i+'" type="radio" '+data.O2Check+'><input type="text" name="option2" id="option2'+data.i+'" value="'+data.O2+'"></li><li><input class="rb" value="3" name="options'+data.i+'" type="radio" '+data.O3Check+'><input type="text" name="option3" id="option3'+data.i+'" value="'+data.O3+'"></li><li><input class="rb" value="4" name="options'+data.i+'" type="radio" '+data.O4Check+'><input type="text" name="option4" id="option4'+data.i+'" value="'+data.O4+'"></li></ul></form><button onclick="editSave(this)" id="Save'+data.i+'">Save</button><button onclick="hideEdit(this)" class="cancel" id="Cancel'+data.i+'">Cancel</button></div>');       
      $('#editform'+data.i).hide();
     },
     error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    }); 
  $('#addQuestion').removeAttr("disabled");
}

function deleteQues(element) {
    var txt;
    var r = confirm("Are you sure you want to delete this question!");
    if (r == true) {
          
           id = element.getAttribute("id").split("delete")[1];
           quesitemid = "#questionitem"+id; 
           editid = "#editform"+id;

          $.ajax({
            url: 'DeleteQues.php',
            type: 'POST',
            data: {
              Course_name: localStorage.Course_name,
              Domain: localStorage.Domain,
              QuestionNum: id,
              QuestionText:$('#QuestionText'+id).val()

            },
            success: function(response) { 
              alert("Question deleted successfully");
              $(quesitemid).remove();
              //$(editid).remove();

             },
             error: function(request,status,errorThrown) {
                 alert(status);
                 alert(errorThrown);
                 alert(request);
             }
            }); 

    } else {
       // txt = "You pressed Cancel!";
    }
}

function addQuestion()
{   
   $('#Questionlist').first().prepend(' <div id = "addform"><form id="addQues" onsubmit="return false;"><label>Question:</label><input type="textarea" id="QuestionText" class="questionarea"></br><label>Options:</label><ul class="QuizList"><li><input class="rb" type="radio" name="options" value="1"><input type="text" id="option1"></li><li><input class="rb" type="radio" name="options" value="2"><input type="text" name="options" id="option2"></li><li><input class="rb" type="radio" name="options" value="3"><input type="text" id="option3"></li><li><input class="rb" type="radio" name="options" value="4"><input type="text" id="option4"></li></ul></form><button onclick="saveQuestion()">Save</button><button onclick="cancelQuestion()">Cancel</button></div>');

   $('#addQuestion').attr("disabled","disabled");
}

function saveQuestion(){

  op = $('input[name=options]:checked').val();
  ans = "#option" + op;
  $.ajax({
    url: 'AdminAddQues.php',
    type: 'POST',
    data: {
      Course_name: localStorage.Course_name,
      Domain: localStorage.Domain,
      QuestionText:$('#QuestionText').val(),
      Option1: $('#option1').val(),
      Option2: $('#option2').val(),
      Option3: $('#option3').val(),
      Option4: $('#option4').val(),
      Answer: $(ans).val()

    },
    success: function(response) { 
      alert("Question saved successfully");
      data = JSON.parse(response);
      //i=1;
      $('#Questionlist').last().append('<li id="questionitem'+data.i+'"><div id="question'+data.i+'"><p class="question">'+data.Q+'</p><ul class="QuizList"><li><input class="rb" type="radio" name="q1" '+data.O1Check+'><label for="q1a">'+data.O1+'</label></li><li><input class="rb" type="radio" name="q'+data.i+'" '+data.O2Check+'><label for="q1b">'+data.O2+'</label></li><li><input class="rb" type="radio" name="q'+data.i+'" '+data.O3Check+'><label for="q1c">'+data.O3+'</label></li><li><input class="rb" type="radio" name="q'+data.i+'" '+data.O4Check+'><label for="q1d">'+data.O4+'</label></li></ul><button onclick="deleteQues(this)" id="delete'+data.i+'" ><img class="editdelete delete" src="images/delete.png" alt=""></button><button onclick="showEdit(this)" class="edit" id="edit'+data.i+'"><img class="editdelete" src="images/edit.png" alt=""></button></div></li>');
      $('#questionitem'+data.i).last().append('<div id = "editform'+data.i+'" class="editform"><form onsubmit="return false;"><input type="textarea" class="questionarea" id="QuestionText'+data.i+'" value="'+data.Q+'"><ul class="QuizList"><li><input class="rb" id="op1'+data.i+'" value="1" name="option'+data.i+'" type="radio" '+data.O1Check+'><input type="text" name="option1" id="option1'+data.i+'" value="'+data.O1+'"></li><li><input class="rb" value="2" id="op2'+data.i+'" name="options'+data.i+'" type="radio" '+data.O2Check+'><input type="text" name="option2" id="option2'+data.i+'" value="'+data.O2+'"></li><li><input class="rb" value="3" id="op3'+data.i+'" name="options'+data.i+'" type="radio" '+data.O3Check+'><input type="text" name="option3" id="option3'+data.i+'" value="'+data.O3+'"></li><li><input class="rb" value="4" id="op4'+data.i+'" name="options'+data.i+'" type="radio" '+data.O4Check+'><input type="text" name="option4" id="option4'+data.i+'" value="'+data.O4+'"></li></ul></form><button onclick="editSave(this)" id="Save'+data.i+'">Save</button><button onclick="hideEdit(this)" class="cancel" id="Cancel'+data.i+'">Cancel</button></div>');       
      $('#editform'+data.i).hide();
     },
     error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    }); 
  $('#addform').remove();
  $('#addQuestion').removeAttr("disabled");

}

function cancelQuestion(){

  $('#addform').remove();
  $('#addQuestion').removeAttr("disabled");

}

