<?php

$user=$_GET['user'];
$cnum=$_GET['cnum'];

$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);


$result=$db->prepare("INSERT INTO Course_Register(Course_number,Username,Payment_status) VALUES ('$cnum','$user',0)");
$result->execute();
if($result)
echo "true";
else
echo "false";

?>