<?php

$userid=$_GET['userid'];

$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";

$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);


$result=$db->prepare("Update COURSE_REGISTER Set Payment_Status=1 WHERE USERNAME='$userid' " );
$result->execute();
if($result)
{
echo "True";
}
else
{
echo "False";
}
?>