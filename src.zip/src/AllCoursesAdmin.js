$(document).ready(function(){
    	
      $.ajax({url: "AllCoursesAdmin.php",success: function(ds){
      var obj = jQuery.parseJSON( ds );

      localStorage.setItem('AllCourses', ds);

      for(var i=0 ; i < obj.length;i++)
      {
       
	   $('#wpl').last().append('<div class="col-sm-4 col-lg-4 col-md-4"><div class="thumbnail"><img src="' + obj[i].i + '" alt=""><div class="caption"><h4 class="pull-right">$'+obj[i].p+'</h4><h4>'+obj[i].c+'</h4><p>Domain: '+obj[i].d+'</p><p>Level: '+obj[i].l+'</p></div><div class="ratings"><button onclick="ViewItem(this)" id="view'+obj[i].cn+'">View Paper</button><button onclick="EditItem(this)" id="edit'+obj[i].cn+'">Edit</button><button onclick="DeleteItem(this)" id="delete'+obj[i].cn+'">Delete</button></div></div>');
  
      }

        }

      });

      $("#FilterButton").click(function(){
      var Domain=$('#Domain').val();
      var Course_Name=$('#Course_Name').val();
      var Level=$('#Level').val();
    
      $.ajax({url: "filterAdmin.php",

        data:{Domain:Domain , Course_Name:Course_Name,Level:Level },
        success: function(ds){

        var obj = jQuery.parseJSON( ds );

         $('#wpl').empty();

          for(var i=0 ; i < obj.length;i++)
          {
           
         $('#wpl').last().append('<div class="col-sm-4 col-lg-4 col-md-4"><div class="thumbnail"><img src="' + obj[i].i + '" alt=""><div class="caption"><h4 class="pull-right">$'+obj[i].p+'</h4><h4>'+obj[i].c+'</h4><p>Domain: '+obj[i].d+'</p><p>Level: '+obj[i].l+'</p></div><div class="ratings"><button onclick="ViewItem(this)" id="view'+obj[i].cn+'">View Paper</button><button onclick="EditItem(this)" id="edit'+obj[i].cn+'">Edit</button><button onclick="DeleteItem(this)" id="delete'+obj[i].cn+'">Delete</button></div></div>');
      
          }
        },

        error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
    });
    });

    $("#AddNewCourse").click(function(){

        window.location.href = "AdminAddItem.html";

    });

    $("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";
        localStorage.clear();

    });

    });


    function DeleteItem(element) {
          
          id = element.getAttribute("id").split("delete")[1];
          var r = confirm("Are you sure you want to delete this course!");
        if (r == true) {
          $.ajax({
            url: 'DeleteItem.php',
            type: 'POST',
            data: {
              CourseNum: id,
            },
            success: function(response) { 
              alert(response);
              location.reload();

             },
             error: function(request,status,errorThrown) {
                 alert(status);
                 alert(errorThrown);
                 alert(request);
             }
            }); 
        }

  }

      function EditItem(element) {

          id = element.getAttribute("id").split("edit")[1];

          data = JSON.parse(localStorage.getItem('AllCourses'));

          for(var i =0; i<data.length; i++){

            if(data[i].cn === id){

              localStorage.setItem("currentCourseEdit",JSON.stringify(data[i]));

            }

          }

          window.location.href = "AdminEditItem.html";

  }

  function ViewItem(element) {

      id = element.getAttribute("id").split("view")[1];

      data = JSON.parse(localStorage.getItem('AllCourses'));

          for(var i =0; i<data.length; i++){

            if(data[i].cn === id){

              localStorage.setItem("Course_name", data[i].c);
              localStorage.setItem("Domain", data[i].d);

            }

          }

      window.location.href = "Admin1.html";

  }

