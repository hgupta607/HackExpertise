<?php
$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";
$Course_Number=$_POST['cnum'];
$Domain=$_POST['domain'];
$p = 1;
$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);

$result=$db->prepare("SELECT COUNT(*) FROM Quiz WHERE Course_Number='$Course_Number' AND Domain = '$Domain'");
$result->execute();
$count = $result->fetchColumn(); 
echo $count;

?>