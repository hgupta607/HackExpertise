  
  var data= JSON.parse(localStorage.getItem('currentTest'));
   var mins = data.t;  //Set the number of minutes you need
    var secs = mins * 60;
    var currentSeconds = 0;
    var currentMinutes = 0;
    /* 
     * The following line has been commented out due to a suggestion left in the comments. The line below it has not been tested. 
     * setTimeout('Decrement()',1000);
     */
    setTimeout(Decrement,1000); 

    function Decrement() {
        currentMinutes = Math.floor(secs / 60);
        currentSeconds = secs % 60;
        if(currentSeconds <= 9) currentSeconds = "0" + currentSeconds;
        secs--;
        document.getElementById("timerText").innerHTML = currentMinutes + ":" + currentSeconds; //Set the element id you need the time put into.
      //  if(secs !== -1) 
        if(secs == -2) 
        {
        alert('Time is over. You will be redirected to the results page.');
        window.location.href = "results.html";        
        }
        else
        setTimeout('Decrement()',1000);
    }