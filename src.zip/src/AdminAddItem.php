<?php 



   $course_name = $_POST["Course_name"];
   $domain = $_POST["Domain"];
   $link = $_POST["ImageLink"];
   $level = $_POST["Level"];
   $price = $_POST["Price"];
   $time = $_POST["Time"];
   $description = $_POST["Description"];
 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{

 	$sql = "INSERT INTO FinalProject.Courses (Course_Name,Domain,Image,Level,Price,Time,Description) VALUES ('$course_name','$domain','$link', '$level','$price','$time','$description')";
 	if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }
 	$conn->close();
 }

?>
