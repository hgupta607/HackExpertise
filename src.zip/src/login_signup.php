<?php 
   $firstname = $_POST["Firstname"];
   $lastname = $_POST["Lastname"];
   $username = $_POST["Username"];
   $email = $_POST["Email"];
   $password = $_POST["password"];
 // Create connection
 $conn = mysqli_connect("localhost", "root", "root");

 // Check connection
 if (!$conn) {
     //die("Connection failed: " . mysqli_connect_error());
     echo "no connection";
 }
else{

  $sql1 = "SELECT * FROM FinalProject.Login WHERE Username = '$username' OR Email = '$email'";
  $result = $conn->query($sql1);

  if ($result->num_rows > 0) {

       echo "Username or email already exits"; 
      
  } else {
      
        $sql2 = "INSERT INTO FinalProject.Login (FirstName,LastName,UserName,Email,pass) VALUES ('$firstname','$lastname','$username', '$email','$password')";
        if ($conn->query($sql2) === TRUE) {
            echo "New user created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
  }
 
 	$conn->close();
 }

?>
