$(document).ready(function() {

  if (localStorage.getItem("UserLoggedIn") !== null) {
    $('#LoggedIn').show();
    $('#logoutbutton').show();
    $('#loginbutton').hide();
    $('#findcourses').show();
    $('#findcoursesadmin').hide();
    $('#LoggedIn').text(localStorage.getItem("UserLoggedIn"));
  }
  else if(localStorage.getItem("AdminLoggedIn") === "true"){
    $('#LoggedIn').show();
    $('#LoggedIn').text("Admin");
    $('#logoutbutton').show();
    $('#loginbutton').hide();
    $('#findcourses').hide();
    $('#findcoursesadmin').show();

  }
  else{
    $('#findcourses').show();
    $('#LoggedIn').hide();
    $('#logoutbutton').hide();
    $('#loginbutton').show();
	$('#findcoursesadmin').hide();
  }


  var index = 0, n ;
  
  var imageList = ["http://cdn8.openculture.com/wp-content/uploads/2014/04/intelligent-books-to-read.jpg","http://cdn1.theodysseyonline.com/files/2016/01/30/635897130380735706-45996608_28ae5ec.jpg","http://livelearnevolve.com/wp-content/uploads/2015/08/11-websites-make-you-genius.jpg","https://s3.amazonaws.com/WisdomPlanet/wisdomtimes/wp-content/uploads/2015/03/The-7-Rules-Of-Personal-Success.jpg","http://nebula.wsimg.com/d383cec3d8a2a1817c42ecf158d86475?AccessKeyId=4A2770B42493A5152F14&disposition=0&alloworigin=1"];

  var length = imageList.length;

  $("#imageframe").attr("src", imageList[index]);

  for(var i=0; i<length; i++){

      n = i+1;

      $('.nav-dots').last().append('<label for="img-1" class="nav-dot" id="'+n+'"></label>');
  }

  $.ajax({
    url: 'Homepage.php',
    type: 'POST',
    data: {},
    success: function(response) { 
      //alert(response);
      data=JSON.parse(response);
      for(var i=0; i<3; i++){
        $("#Img"+(i+1)).attr("src", data[i].Image);
        $("#Course"+(i+1)).text(data[i].Course_Name);
        $("#Price"+(i+1)).text("Price : "+data[i].Price+"$");
        $("#Domain"+(i+1)).text("Domain : "+data[i].Domain);
        $("#Level"+(i+1)).text("Level : "+data[i].Level);

      }

     },
     error: function(request,status,errorThrown) {
         alert(status);
         alert(errorThrown);
         alert(request);
     }
 });

$(".next").click(function() {

    if(index == length-1){
      index = 0;
    }
    else{
      index = index+1;
    }

  $("#imageframe").fadeOut(200, function() {
            $("#imageframe").attr('src',imageList[index]);
    }).fadeIn(200);
  
});

$(".prev").click(function() {
  
  if(index == 0){
      index = length - 1;
  }
    else{
      index = index-1;
    }

   $("#imageframe").fadeOut(200, function() {
            $("#imageframe").attr('src',imageList[index]);
    }).fadeIn(200);

});

$(".nav-dot").click(function() {

  index = parseInt(this.getAttribute("id"))-1;

  $("#imageframe").fadeOut(200, function() {
            $("#imageframe").attr('src',imageList[index]);
    }).fadeIn(200);
  
});

$("#findcourses").click(function() {
  window.location.href = 'ac.html';
});
$("#findcoursesadmin").click(function() {
  window.location.href = 'AllCoursesAdmin.html';
});

$("#loginbutton").click(function() {
  window.location.href = 'login.html';
});

    $("#logoutbutton").click(function(){

        window.location.href = "Homepage.html";
        localStorage.clear();

    });


});