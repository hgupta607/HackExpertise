
//store user answers

var user_ans=[];
var userid=localStorage.getItem("UserLoggedIn");
 
function radiocl (x) {
var i = x.getAttribute('name');
var  qli=JSON.parse(localStorage.getItem('qlist'));
user_ans.length=qli.length;
//var a=x.getAttribute('value');
for(var h=0;h<qli.length;h++)
{
if(qli[h]==i)
{
user_ans[h]=x.getAttribute('value');
}
}
}


  
  var dataTime= JSON.parse(localStorage.getItem('currentTest'));
   var mins = dataTime.t;  //Set the number of minutes you need
    var secs = mins * 60;
    var currentSeconds = 0;
    var currentMinutes = 0;
    /* 
     * The following line has been commented out due to a suggestion left in the comments. The line below it has not been tested. 
     * setTimeout('Decrement()',1000);
     */
    setTimeout(Decrement,1000); 

    function Decrement() {
        currentMinutes = Math.floor(secs / 60);
        currentSeconds = secs % 60;
        if(currentSeconds <= 9) currentSeconds = "0" + currentSeconds;
        secs--;
        document.getElementById("timerText").innerHTML = currentMinutes + ":" + currentSeconds; //Set the element id you need the time put into.
      //  if(secs !== -1) 
        if(secs == -2) 
        {
        alert('Time is over. You will be redirected to the results page.');
		calculateresult();     
        }
        else
        setTimeout('Decrement()',1000);
    }


$(document).ready(function(){

	$('#LoggedIn').text(localStorage.getItem("UserLoggedIn"));
	var data= JSON.parse(localStorage.getItem('currentTest'));
	var cnum = data.cn;
	var domain = data.d;
	var qlist=[]; 

	//run the php file
	jqxhr = $.ajax({type:'GET',
    	url: "test_ques.php",
    	dataType: "json",data:{cnum:cnum , domain:domain},
	}); 

//calculate question numbers
	jqxhr.done(function(catalog) {
		//list of questions
		var qlist=[];
		//list of correct answers
		var anslist=[];
		for (var i=0;i<catalog.length;i++)
   		{
   			if(jQuery.inArray(catalog[i].qno,qlist)==-1)
   			{
   				qlist.push(catalog[i].qno) ;
   			}
   		}

			localStorage.setItem("qlist",JSON.stringify(qlist));
		var r = 0;
		for (var i=0;i<qlist.length;i++)
		{
			var d = qlist[i];
			//$("#ques").last().append('<h3>Q '+(i+1)+': '+catalog[d].qtext+'</h3>');
			//var key = catalog[d].qno;
			//var count = [];
			var a=0,b=0;

			while(b<catalog.length){	
				if(catalog[b].qno == qlist[i])
			   	{
			   		$("#ques").last().append('<h3>Q '+(i+1)+': '+catalog[b].qtext+'</h3>');
			   			break;
			   		}
			   		b++;
			   		
		   	}
			
			$('#ques').last().append('<ol class="answers> hi"');
			
			for (var k=0;k<4;k++)
			{	
				if(catalog[r].ans==1)
				{
					anslist[i]=catalog[r].opt;
				}

				var radiobut = $('<li class="'+k+'"><input type="radio" onclick="radiocl(this)" name = "'+qlist[i]+'" class="radios "  value="'+catalog[r].opt+'"/>'+catalog[r].opt+'<br/></li>');
	 			radiobut.appendTo;
	 			$('#ques').last().append(radiobut);
	 			r=r+1;
  			}
			
		}
		
		localStorage.setItem("anslist",JSON.stringify(anslist));
		
	});
	
	$('#submit').click(function() {
calculateresult();

	});


});


function calculateresult() {
	 var  anslist=JSON.parse(localStorage.getItem('anslist'));
	 var total=0;
	for(var p=0;p<anslist.length;p++)
	
	{
	if(anslist[p]==user_ans[p])
		total=total+1;
	}
	var percent = (total/anslist.length)*100;
	var data= JSON.parse(localStorage.getItem('currentTest'));
	var regid = data.regid;
	$.ajax({url: "test_result.php",data:{percent:percent,regid:regid},success: function(ds){
	alert(ds);
	window.location.href = "mc.html";
	},
	error: function(){
	alert("did not happen");
	}
	});

}
