<?php

$userid=$_GET['userid'];

$host="localhost";
$username="root";
$password="root";
$dbname="FinalProject";

$res_row=array();
$db = new PDO("mysql:dbname=$dbname;host=$host", $username, $password);

$result=$db->prepare("DELETE FROM COURSE_REGISTER WHERE USERNAME='$userid' and payment_status=0" );
$result->execute();
if($result)
{
echo "True";
}
else
{
echo "False";
}
?>